# ÉCLAT — Luxury Concept Store

A responsive, animated single-page luxury concept-store website.

## Publish with GitHub Pages

1. Upload `index.html` to the root of the `main` branch.
2. Open **Settings → Pages** in the repository.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/ (root)`, then save.
5. Wait for the deployment to finish. The public URL will be:
   `https://pujabhemani07.github.io/eclat-luxury-store/`

## Notes

This is a front-end concept/demo. Product data and images are sample content. The cart is client-side only; payment, inventory, shipping, customer accounts and order processing are not connected. Replace sample products, prices, imagery, brand details and policies before using it as a live store.
